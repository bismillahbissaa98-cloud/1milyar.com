1MILYAR.COM - APLIKASI PENJUALAN ANDROID

Fitur versi awal:
- Dashboard seperti referensi
- Penjualan
- Pembelian
- Stok / Produk
- Dana Masuk / Dana Keluar
- No. transaksi dapat diubah manual
- Data tersimpan di perangkat melalui localStorage
- Backup data JSON

CARA MEMBUAT APK:
1. Buka folder ini di Android Studio.
2. Tunggu Gradle selesai sinkronisasi.
3. Pilih Build > Build APK(s).
4. APK debug biasanya berada di app/build/outputs/apk/debug/app-debug.apk

Catatan:
Project ini memakai Android WebView sehingga tampilan HTML dapat dikembangkan tanpa mengubah struktur aplikasi Android.
