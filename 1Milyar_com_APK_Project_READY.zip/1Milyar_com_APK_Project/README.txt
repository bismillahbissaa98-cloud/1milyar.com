1Milyar.com APK

Project Android Studio/Gradle dengan WebView yang membungkus aplikasi HTML.
APK debug dibangun otomatis oleh GitHub Actions workflow .github/workflows/build-apk.yml.

Cara build di GitHub:
1. Upload seluruh isi folder project ini ke repository.
2. Commit ke branch main.
3. Buka Actions > Build 1Milyar.com APK.
4. Tunggu sampai hijau.
5. Buka run yang berhasil > Artifacts > 1Milyar-com-debug-apk > download ZIP.
6. Ekstrak dan instal app-debug.apk di Android.
